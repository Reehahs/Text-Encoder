/*
 * huffman_bst.c
 *
 *  Created on: Nov. 14, 2020
 *      Author: Joseph Perasud
 */

#include "huffman_bst.h"
#include "frequency_list.h"

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

huffman_tree *initialise_tree(){
	huffman_tree *tree;
	tree = malloc( sizeof( *tree) );

	tree->count = 0;
	tree->root = NULL;

	return(tree);
}
/* takes a frequency list and fills a tree. The output
 * is a full tree ready for traversal
 * @param *tree: takes an empty tree and fills it
 * @param *list: the list the tree will be filled with
 * */
void fill_tree(huffman_tree *tree, freq_list *list){
	while (list->count > 1){
		huffman_node *child_left;
		huffman_node *child_right;
		huffman_node *parent;

		child_left = malloc( sizeof( *child_left) );
		child_right= malloc( sizeof( *child_right) );
		parent= malloc( sizeof( *parent) );

		if (list->first->left != NULL){
			child_left = list->first->left;
		}
		else if(list->first->symbol == NULL){
			child_left = list->first;
		}
		else{
			child_left-> frequency = list->first->frequency;
			child_left-> symbol = list->first->symbol;
		}
		list->first = list->first->right;

		if (list->first->left != NULL){
			child_right = list->first->left;
		}
		else if(list->first->symbol == NULL){
					child_left = list;
		}
		else{
			child_right-> frequency = list->first->frequency;
			child_right-> symbol = list->first->symbol;
		}
		list->first = list->first->right;

		list->count -= 1;
		parent->frequency = child_left->frequency + child_right->frequency;
		parent->right = child_right;
		parent->left = child_left;
		parent->symbol = NULL;

		insert_parent(list, parent);

	}
	tree->root = list->first->left;

	return;
}

/* function used by the "fill_tree" to add tree nodes to
 * a list. The node needs to be inserted ascending order
 * to build the tree correctly
 * @param *list: a pointer to a list
 * @param *node: a pointer to a tree node that will be
 * 		added to the list
 * */
void insert_parent(freq_list *list, huffman_node *node){
	huffman_node *temp_node;
	temp_node= malloc( sizeof( *temp_node) );
	temp_node->left = node;
	temp_node->symbol = NULL;
	temp_node->frequency = node->frequency;

	if(list->count == 1){			//if: used to determine where in the list
		temp_node->right = NULL;	//to put the tree node
		list->first = temp_node;
		list->last = temp_node;
	}
	else if (node->frequency > list->last->frequency){
		temp_node->right= NULL;
		list->last->right = temp_node;
		list->last = temp_node;
	}
	else if(node->frequency <= list->first->frequency){
		temp_node->right = list->first;
		list->first = temp_node;
	}
	else{											//else is means that the tree node belongs
		huffman_node *pptr = list->first;			//neither at the beginning nor the end
		huffman_node *nptr = list->first->right;	//and thus the list needs to be traversed
		while (node->frequency > nptr->frequency){
			pptr = nptr;
			nptr = nptr->right;
		}
		pptr->right = temp_node;
		temp_node->right = nptr;
	}
	return;
}
