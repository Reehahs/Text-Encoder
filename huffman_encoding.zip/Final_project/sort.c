/*
 * sort.c
 *  Description, it does selection sort on a linked list (ended up not using but thought we needed it so I made it)
 *  Created on: Nov. 27, 2020
 *      Author: Shaheer Khan
 */
#include <stdio.h>
#include <stdlib.h>
#include "frequency_list.h"
#include "huffman_bst.h"

//Insertion Sort Frequency List
// Function to insert a given node in a sorted linked list 
void sort_insert(huffman_node** first, huffman_node* new_node);

void insertionSort(huffman_node **first) 
{ 
    // Initialize sorted linked list 
    huffman_node *sorted = NULL; 
  
    // Traverse the given list and insert every node to sorted 
    huffman_node *curr = *first; 
    while (curr != NULL) 
    { 
        // Store right for right iteration 
        huffman_node *right = curr->right; 
  
        // insert curr in sorted linked list 
        sort_insert(&sorted, curr); 
  
        // Update curr 
        curr = right; 
    } 
  
    // Update first to point to sorted linked list 
    *first = sorted; 
} 

void sort_insert(huffman_node** first, huffman_node* new_node) 
{ 
    huffman_node* curr; 
    /* Special case for the end */
    if (*first == NULL  || (*first)->frequency <= new_node->frequency) { 
        new_node->right = *first; 
        *first = new_node; 
    } 
    else { 
        curr = *first; 
        while (curr->right != NULL && curr->right->frequency > new_node->frequency) { 
            curr = curr->right; 
        } 
        new_node->right = curr->right; 
        curr->right = new_node; 
    } 
} 


