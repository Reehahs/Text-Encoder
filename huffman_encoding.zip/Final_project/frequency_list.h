/*
 * frequency_list.h
 *
 *  Created on: Nov. 15, 2020
 *      Author: Joseph Perasud
 */

#ifndef SRC_FREQUENCY_LIST_H_
#define SRC_FREQUENCY_LIST_H_

//
// Structures
//
/* these nodes are used for both lists
 * and trees
 * */
typedef struct huffman_node {
	int 				frequency;	//
	int 				symbol;		//
//	int              	height;		// Height of the current node.
	struct huffman_node *left;		// Pointer to the left child.
									// (only used for trees)
	struct huffman_node *right;		// Pointer to the right child.
}huffman_node ;

typedef struct {		//
	huffman_node *first;// first node of the list
	huffman_node *last;	// last node of the list
	int count;			// number of nodes in the list
} freq_list;			// name of structure

//
// Functions
//
void insert_list(freq_list *list, const int symbol);
										//
freq_list *initialise_freq_list();
										//
void update_freq_list(freq_list *list,
					  const int symbol);
										//
void print_freq_list(freq_list *list);
										//
void freq_list_sort(freq_list *list);

void insert_order(freq_list *list, huffman_node *node);

#endif /* SRC_FREQUENCY_LIST_H_ */
