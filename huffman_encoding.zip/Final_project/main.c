/*
 * main.c
 * Description: Main program to initiate the project
 * 
 * This program is able to take a small text file, encode it using huffman encoding, and can also decode the encoded huffman file. 
 * 
 * 	Group members:
 * 	Joseph Persaud: pers2490@mylaurier.ca, 190602490
	Jasmeet Salh: salh0960@mylaurier.ca, 190770960
	Shaheer Khan: khan9383@mylaurier.ca, 190693830
	Matt Rosa: rosa7230@mylaurier.ca, 180437230
 *
 *  Created on: Nov. 14, 2020
 *      Author: Jasmeet Salh
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "frequency_list.h"
#include "huffman_bst.h"

int main(void){
//frequency list
	setbuf(stdout, NULL);

	freq_list *list = initialise_freq_list();
	FILE *file;
	
	int c;
	//Opening the file
	file = fopen("short.txt","r");

	//if statement for file
	if (file) {
	    while ((c = getc(file)) != EOF){
	    	update_freq_list(list,c);
	    }
		fclose(file);
	}

//	print_freq_list(list);

//sort
	print_freq_list(list);

//huffman tree
	huffman_tree *tree = initialise_tree();
	fill_tree(tree, list);
	printf("end\n");

//encoding file
	//opening the file
	file = fopen("short.txt","r");
	encoding_huffman_tree(tree,file);
	fclose(file); //Closing the file
	printf("Done Encoding");

//decoding file
	char x[10000];
	char y;
	const char *z=(const char*)malloc(sizeof(char));
	char decoded;

	//Opening the file in r mode
	file = fopen("encoding_text.txt","r");
	//If statement including the scanf operation
	if (file) {
	    fscanf(file,"%s",x);
	}
	//Closing the file
	fclose(file);
	decode(tree->root,x);
	printf("\nDone decoding, file saved");
	return 0; //return statement and end of program
}
