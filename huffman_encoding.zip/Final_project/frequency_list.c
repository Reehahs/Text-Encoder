/*
 * frequency_list.c
 *	DESCRIPTION:  sort the characters in ascending order by frequency.
 *  Created on: Nov. 15, 2020
 *      Author: Joseph Perasud
 */

#include "frequency_list.h"
#include <stdlib.h>
#include <stdio.h>

/* initialises a frequency list
 * */
freq_list *initialise_freq_list(){
	freq_list *list;
	list = malloc( sizeof( *list) );

	list->first = NULL;
	list->last = NULL;
	list->count = 0;

	return(list);
}

/* function used by main to check update the freq_list
 * user should never have to input something manually
 * since inputs will always be directly read form a file
 * @param *list: an already existing list
 * @param symbol: symbol having it's frequency updated
 * */
void update_freq_list(freq_list *list, const int symbol){
	if (list->first == NULL){		//creates first node for list
		insert_list(list, symbol);
	}
	else{
		huffman_node *n = list->first;
		huffman_node *previous = NULL;
		while (n != NULL){				//checks if symbol already
			if (n->symbol == symbol){	//exists
				n->frequency++;

				/* the following while loop is used to sort the
				 * list as it's being created. It works. Don't
				 * touch it. It does not interact with anything
				 * else so leave it alone
				 * */
				while(n->right != NULL &&						//loops to ensure 3->2->2
						n->frequency > n->right->frequency){	//becomes 2->2->3 and not 2->3->2
					if (previous != NULL){
						previous->right = n->right;
						n->right = previous->right->right;
						previous->right->right = n;
						previous = previous->right;
						if(n->right == NULL){
							list->last = n;
						}
					}
					else{								//deals with list
						list->first = n->right;			//when there's no
						n->right = list->first->right;	//"previous node"
						list->first->right = n;			//i.e. needs to swap
						previous = list->first;			//the first and second node
					}
				}
				break;
			} // if (n->symbol == symbol)
			previous = n;
			n = n->right;
		} // while (n != NULL)
			if (n == NULL){					//symbol does not yet
				insert_list(list, symbol);	//exist in list
			}
	} // if (list->first == NULL)
	return;
}
/* function used by "update_freq_list" This function
 * adds a new element to the list. "update_freq_list"
 * ensures only non-existing elements will be inserted
 * */
void insert_list(freq_list *list, const int symbol){
	huffman_node *n;

	n = malloc(sizeof *n);
	n->symbol = symbol;
	n->frequency = 1;
	n->right = NULL;
	n->left = NULL;

	if (list->first == NULL){ // i.e. if the list is empty
		list->first = n;
		list->last = n;
	}
	else{
		n->right = list->first;
		list->first = n;
	}
	list->count++;
	return;
}

/* used exclusively for print the contents of a frequency list
 * @param *list: pointer to list that will be printed
 * */
void print_freq_list(freq_list *list){
	huffman_node *n = list->first;
	while(n != NULL){
		printf("%c -> %d\n",n->symbol,n->frequency);
		n = n->right;
	}
	printf("===\n");
	return;
}

