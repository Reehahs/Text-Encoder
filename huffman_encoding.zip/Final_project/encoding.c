/*
 * encoding.c
 *  DESCRIPTION: a function that can traverse the tree to get the binary encoding for a character 
 *  Created on: Nov. 28, 2020
 *      Author: shaheer Khan
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "frequency_list.h"
#include "huffman_bst.h"

#define MAX_SIZE 100

typedef struct letterNode{
    int         aLetter;        //the symbol of the letter node
    char        binaryCode[100];     //the binary associated with each symbol 
    struct LetterNode  *next;   //a pointer to the next letterNode
}LetterNode;

typedef struct letterList{
	LetterNode *first;  // first node of the list
    LetterNode *last;   //last node of the list
	int count;		    // number of nodes in the list
}LetterList;		// name of structure



void encoding_aux(huffman_node *node,LetterList *letter,char binary[]){
    if (node->symbol!=NULL){ //if it reached a leaf node
    	LetterNode *letterNode=(LetterNode *)malloc(sizeof(LetterNode)); //creates a letter node 

        //Gives the letter node properties of the leaf node and its binary repersentation
    	letterNode->aLetter = node->symbol;
        strcpy(letterNode->binaryCode,binary);
        letterNode->next = NULL;

        if (letter->first==NULL){				//if list is empty it makes the letterNode, the first node on the list
           	letter->first = letterNode;
        	letter->last = letterNode;
        }
        else{                                  //else the node is just added onto the list
            letter->last->next = letterNode;
            letter->last=letterNode;
        }
        return; //return statement 
    }
    // else if it did not reach a leaf node
    else{
        strcat(binary,"0");
        encoding_aux(node->left,letter,binary);         //recursive loop until leaf node is hit. 
        binary[strlen(binary)-1] = NULL;
        strcat(binary,"1");
        encoding_aux(node->right,letter,binary);
        binary[strlen(binary)-1] = NULL;
        return;
    }
}

//Linear search to search for the node which corresponds to the letter being encoded
LetterNode* linear_search(LetterList *list, int letter){ 

    if(list->first->aLetter == letter){
        return list->first;
    }

    else if(list->last->aLetter==letter){
        return list->last;
    }

    else{
        LetterNode *temp=(LetterNode *)malloc(sizeof(LetterNode));
        temp=list->first;
        int found = 0;
        while(temp->aLetter!=list->last->aLetter && found == 0){
            temp=temp->next;
            if(temp->aLetter==letter){
                found=1;
            }
        }
        return temp;
    }
}

//The main function which encode the file given to it using the huffman tree
void encoding_huffman_tree(huffman_tree *tree,FILE *readFile){

    int c;
    //opening the file in w mode
    FILE *file;
	file = fopen("encoding_text.txt","w");

    LetterList *codePerLetter=(LetterList *)malloc(sizeof(LetterList));
    LetterNode *temp;
    char binary[100];
    binary[0] = NULL;
    codePerLetter->first = NULL;
    codePerLetter->last = NULL;

    encoding_aux(tree->root,codePerLetter,binary);

    while ((c = getc(readFile)) != EOF){
	    temp=linear_search(codePerLetter,c);
        //printing to the file using fprintf 
        fprintf(file,"%s",temp->binaryCode);
	}
    //closing the file and return statement
	fclose(file);
    return;
}

