/*
 * decode.c
 *	DESCRIPTION: a function that can traverse the tree read an encoded and output the message properly
 *  Created on: Nov. 29, 2020
 *      Author: Matt rosa and Shaheer khan
 */

#include "huffman_bst.h"
#include "frequency_list.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

//Decode only works on small encoded files
void decode(struct huffman_node* root, char s[]) {
	char x[10000];
	struct huffman_node* node = root;

	//Opening the file in w mode to write
	FILE *fileWrite;
	fileWrite = fopen("decoded.txt","w");
	//For loop which goes through the tree in order the find the leaf node
	for (int i = 0; i < strlen(s); i++) {
		if (s[i] == '0' && node->left != NULL){
			node = node->left;
		}
		else if (s[i] == '1' && node->right !=NULL){
			node = node->right;
		}
		if (node->symbol != NULL) {
			char *temp;
			sprintf(temp,"%c",node->symbol);
	    	strcat(x,temp);
			node = root;
		} 
	}
	//printing to the file with fprintf
	fprintf(fileWrite,"%s",x);
	fclose(fileWrite); //closing the file
	//return statement
	return;
}