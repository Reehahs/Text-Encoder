/*
 * huffman_bst.h
 *
 *  Created on: Nov. 14, 2020
 *      Author: persa
 */

#ifndef SRC_HUFFMAN_BST_H_
#define SRC_HUFFMAN_BST_H_

#include "frequency_list.h"

typedef struct huffman_tree{
	int            count;                   ///< Number of nodes in the BST.
	huffman_node   *root;                   ///< Pointer to the root node of the BST.
} huffman_tree;

huffman_tree *initialise_tree();

void fill_tree(huffman_tree *tree, freq_list *list);

#endif /* SRC_HUFFMAN_BST_H_ */
